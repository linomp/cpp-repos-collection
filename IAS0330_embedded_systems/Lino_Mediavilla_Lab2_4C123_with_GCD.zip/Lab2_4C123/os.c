// os.c
// Runs on LM4F120/TM4C123/MSP432
// Lab 2 starter file.
// Daniel Valvano
// February 20, 2016

#include <stdint.h>
#include "os.h"
#include "../inc/CortexM.h"
#include "../inc/BSP.h"

#define NULL 0

void StartOS(void);

tcbType tcbs[NUMTHREADS];
tcbType *RunPt;
int32_t Stacks[NUMTHREADS][STACKSIZE];

uint64_t Counter; // "time" counter for periodic tasks
uint64_t limit;

// function pointers to later point to arbitrary tasks
// task periods given in [ms]
void (*PeriodUserTask1)(void);
uint32_t PTask1Period; 

void (*PeriodUserTask2)(void);
uint32_t PTask2Period;

uint32_t Mailbox;  // shared data
int32_t Send; // semaphore 


void OS_Init(void){
  DisableInterrupts();
  BSP_Clock_InitFastest();
	  
  Counter = 0;  
  PTask1Period = 0; 
  PTask2Period = 0; 
	
	Mailbox= 0; // dummy initial value for mailbox data
  Send = 0; // semaphore 
}

void SetInitialStack(int i){
  // save important register addresses into thread stack
  tcbs[i].sp = &Stacks[i][STACKSIZE-16]; // thread stack pointer 
  Stacks[i][STACKSIZE-1] = 0x01000000; // Thumb bit 
  Stacks[i][STACKSIZE-3] = 0x14141414; // R14 
  Stacks[i][STACKSIZE-4] = 0x12121212; // R12 
  Stacks[i][STACKSIZE-5] = 0x03030303; // R3 
  Stacks[i][STACKSIZE-6] = 0x02020202; // R2 
  Stacks[i][STACKSIZE-7] = 0x01010101; // R1 
  Stacks[i][STACKSIZE-8] = 0x00000000; // R0 
  Stacks[i][STACKSIZE-9] = 0x11111111; // R11 
  Stacks[i][STACKSIZE-10] = 0x10101010; // R10 
  Stacks[i][STACKSIZE-11] = 0x09090909; // R9 
  Stacks[i][STACKSIZE-12] = 0x08080808; // R8 
  Stacks[i][STACKSIZE-13] = 0x07070707; // R7 
  Stacks[i][STACKSIZE-14] = 0x06060606; // R6 
  Stacks[i][STACKSIZE-15] = 0x05050505; // R5 
  Stacks[i][STACKSIZE-16] = 0x04040404; // R4 
}

// Add four main threads to the scheduler
int OS_AddThreads(void(*thread0)(void),
                  void(*thread1)(void),
                  void(*thread2)(void),
                  void(*thread3)(void)){ 
	
  // initialize TCB circular list 										
	int32_t status; 
  status = StartCritical(); 
  tcbs[0].next = &tcbs[1]; // 0 points to 1 
  tcbs[1].next = &tcbs[2]; // 1 points to 2
  tcbs[2].next = thread3 ? &tcbs[3] : &tcbs[0]; // 2 points to thread 3 if there is one
	if (thread3) tcbs[3].next = &tcbs[0]; // 3 points to 0 
	
  // initialize four stacks, including initial PC										
  SetInitialStack(0); Stacks[0][STACKSIZE-2] = (int32_t)(thread0); // PC
  SetInitialStack(1); Stacks[1][STACKSIZE-2] = (int32_t)(thread1); // PC
  SetInitialStack(2); Stacks[2][STACKSIZE-2] = (int32_t)(thread2); // PC
  SetInitialStack(3); Stacks[3][STACKSIZE-2] = (int32_t)(thread3); // PC
  
	// initialize RunPt (thread 0 will run first)									
  RunPt = &tcbs[0];  
  EndCritical(status);  							
										 
  return 1;   
}

// Particular case with just 3 threads, for debugging
int OS_AddThreads3(void(*task0)(void),
                 void(*task1)(void),
                 void(*task2)(void)){ 
									 
  return OS_AddThreads(task0, task1, task2, NULL);
}


uint64_t gcd(uint32_t n1, uint32_t n2){
	int i = 0;
	for(i=1; i <= n1 && i <= n2; ++i)
	{
			// Checks if i is factor of both integers
			if(n1%i==0 && n2%i==0)
					return i;
	}
}

// Current version supports 2 periodic tasks. Periods given in [ms]
int OS_AddPeriodicEventThreads(void(*thread1)(void), uint32_t period1,
  void(*thread2)(void), uint32_t period2){
 
	// assign user tasks given as function pointers, and task periods	

	PeriodUserTask1 = thread1;
  PTask1Period = period1;	
  
  PeriodUserTask2 = thread2;
  PTask2Period = period2;			
		
	limit = gcd(PTask1Period, PTask2Period);
		
  return 1; 
}


void OS_Launch(uint32_t theTimeSlice){
  STCTRL = 0;                  // disable SysTick during setup
  STCURRENT = 0;               // any write to current clears it
  SYSPRI3 =(SYSPRI3&0x00FFFFFF)|0xE0000000; // priority 7
  STRELOAD = theTimeSlice - 1; // reload value
  STCTRL = 0x00000007;         // enable, core clock and interrupt arm
  StartOS();                   // start on the first task
}


// runs every ms
void Scheduler(void){ 
	
	Counter = (Counter+1) % INT32_MAX; // increment "time" counter, prevent overflow
	//Counter = (Counter+1)%limit;  // did not work :/
	
	// run periodic tasks
	if( (Counter % PTask1Period) == 0){  
    PeriodUserTask1();
  }
  if( (Counter % PTask2Period) == 0){ 
    PeriodUserTask2();
  }
	
	// Run corresonding main thread
  RunPt = RunPt->next; // Round Robin scheduler
}



void OS_InitSemaphore(int32_t *semaPt, int32_t value){
  // force atomic operation
	DisableInterrupts();
	*semaPt = value;
	EnableInterrupts();
}

/*** Implementation of the spin-lock semaphore from section 2.4.1 ***/

// a thread that calls this, will block until another one increments the semaphore counter above zero (with OS_Signal)
void OS_Wait(int32_t *s){
	DisableInterrupts();
  while((*s) == 0){
    EnableInterrupts();  // a window of time for threads to call OS_Signal
    DisableInterrupts();
  }
  (*s) = (*s) - 1;
  EnableInterrupts();
}

// increments counter so a given thread blocked by OS_Wait can continue
void OS_Signal(int32_t *s){ 
	DisableInterrupts();
  (*s) = (*s) + 1;
  EnableInterrupts();
}


// set a global variable as semaphore
void OS_MailBox_Init(void){
	OS_InitSemaphore(&Send, 0);
}


void OS_MailBox_Send(uint32_t data){ 
	Mailbox = data; // write to Mailbox
	OS_Signal(&Send); // indicate there is data available. Consumer that was blocked by OS_Wait, shall continue. 
}


uint32_t OS_MailBox_Recv(void){ 
	uint32_t data; 
		
  OS_Wait(&Send); // block until there is data available
  data = Mailbox; // read Mailbox data
	
  return data; 
}


