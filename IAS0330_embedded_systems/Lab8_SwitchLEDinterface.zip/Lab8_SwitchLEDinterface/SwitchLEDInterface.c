#include "TExaS.h"
#include "tm4c123gh6pm.h"

unsigned long SW1;  // input from PE0
unsigned long Out;  // output to PE1

void DisableInterrupts(void); 
void EnableInterrupts(void);

void PortE_Init(void);
void Delay100ms(unsigned long);

// PE0, PB0, or PA2 connected to positive logic momentary switch using 10k ohm pull down resistor
// PE1, PB1, or PA3 connected to positive logic LED through 470 ohm current limiting resistor
int main(void){ 
	
	/* Grader setup */
	TExaS_Init(SW_PIN_PE0, LED_PIN_PE1, ScopeOn);
  EnableInterrupts();
	
	// I/O init ritual
	PortE_Init();
	
	while(1){ 
		SW1 = GPIO_PORTE_DATA_R&0x1;  // read PE0 into SW1
		
		if(SW1){
			// turn on led
			GPIO_PORTE_DATA_R = 0x2;
			// wait approx 100 ms
			Delay100ms(1l);
			// turn off 
			GPIO_PORTE_DATA_R = 0x0;
			// wait approx 100 ms
			Delay100ms(1l);
		} else{
			GPIO_PORTE_DATA_R = 0x2;
		}
  }
  
}

void PortE_Init(void){ 
	volatile unsigned long delay;
  SYSCTL_RCGC2_R |= 0x10;     // 1) enable clock for port E
  delay = SYSCTL_RCGC2_R;     // Delay for stabilization       
  GPIO_PORTE_AMSEL_R = 0x0;   // 3) disable analog function
  GPIO_PORTE_PCTL_R = 0x0;    // 4) GPIO clear bit PCTL  
  GPIO_PORTE_DIR_R = 0x2;     // 5) 0000.0010 == PE0 input, PE1 output 
  GPIO_PORTE_AFSEL_R = 0x0;   // 6) no alternate function
	GPIO_PORTE_PUR_R = 0x0;     // Positive logic; No need to enable pullup resistor on PE0       
  GPIO_PORTE_DEN_R = 0x3;     // 7) enable digital pins PE1 and PE0        
}

void Delay100ms(unsigned long time){
  unsigned long i;
  while(time > 0){
    i = 1333333;  // this number means 100ms
    while(i > 0){
      i = i - 1;
    }
    time = time - 1; // decrements every 100 ms
  }
}
