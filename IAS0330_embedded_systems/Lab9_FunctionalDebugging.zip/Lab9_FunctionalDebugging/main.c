#include "TExaS.h"
#include "tm4c123gh6pm.h"

#include <stdbool.h>
 
unsigned long SW1, SW2;  // input from PF0 and PF4
 
void DisableInterrupts(void);  
void EnableInterrupts(void);   

void PortF_Init(void){ volatile unsigned long delay;
  SYSCTL_RCGC2_R |= 0x00000020;     // 1) activate clock for Port F
  delay = SYSCTL_RCGC2_R;           // allow time for clock to start
  GPIO_PORTF_LOCK_R = 0x4C4F434B;   // 2) unlock GPIO Port F
  GPIO_PORTF_CR_R = 0x1F;           // allow changes to PF4-0
  // only PF0 needs to be unlocked, other bits can't be locked
  GPIO_PORTF_AMSEL_R = 0x00;        // 3) disable analog on PF
  GPIO_PORTF_PCTL_R = 0x00000000;   // 4) PCTL GPIO on PF4-0
  GPIO_PORTF_DIR_R = 0x0E;          // 5) PF4,PF0 in, PF3-1 out
  GPIO_PORTF_AFSEL_R = 0x00;        // 6) disable alt funct on PF7-0
  GPIO_PORTF_PUR_R = 0x11;          // enable pull-up on PF0 and PF4
  GPIO_PORTF_DEN_R = 0x1F;          // 7) enable digital I/O on PF4-0
}

// Initialize SysTick with busy wait running at bus clock.
void SysTick_Init(void){
  NVIC_ST_CTRL_R = 0;                   // disable SysTick during setup
  NVIC_ST_RELOAD_R = 0x00FFFFFF;        // maximum reload value
  NVIC_ST_CURRENT_R = 0;                // any write to current clears it             
  NVIC_ST_CTRL_R = 0x00000005;          // enable SysTick with core clock
}
unsigned long Led;
 
/*
Old inaccurate Delay function 

void Delay(void){unsigned long volatile time;
  //time = 160000; // 0.1sec
  time = 80000; // 0.05 sec?  -- actually not accurate to only divide by 2...
  
	while(time){
   time--;
  }
}
*/ 

/* 
	Taken from the C9_Debugging sample project 
  users.ece.utexas.edu/~valvano/arm/C9_Debugging.zip

	Time delay using busy wait.
	The delay parameter is in units of the core clock.
*/
void SysTick_Wait(unsigned long delay){
  volatile unsigned long elapsedTime;
  unsigned long startTime = NVIC_ST_CURRENT_R;
  do{
    elapsedTime = (startTime-NVIC_ST_CURRENT_R)&0x00FFFFFF;
  }
  while(elapsedTime <= delay);
}
void SysTick_Wait10ms(unsigned long delay){
  unsigned long i;
  for(i=0; i<delay; i++){
    SysTick_Wait(160000); 
  }
}
 

unsigned long Time[50]; 
unsigned long Data[50];

int main(void){  
	unsigned long i,last,now; 
	
	TExaS_Init(SW_PIN_PF40, LED_PIN_PF1);  // activate grader and set system clock to 16 MHz
  PortF_Init();   // initialize PF1 to output
  SysTick_Init(); // initialize SysTick, runs at 16 MHz
  i = 0;          // array index
  last = NVIC_ST_CURRENT_R;
  EnableInterrupts(); 
  	
	while(1){				
		SW1 = GPIO_PORTF_DATA_R & 0x1;  	// read PF0
		SW2 = GPIO_PORTF_DATA_R & 0x10; 	// read PF4 
		
		if(SW1 && SW2){ 									// both not pressed
			GPIO_PORTF_DATA_R = 0x0; 
		}else{
			Led = GPIO_PORTF_DATA_R;   			// read previous
			Led = Led^0x02;            			// toggle red LED
			GPIO_PORTF_DATA_R = Led;   			// output 
			if(i<50){
				now = NVIC_ST_CURRENT_R;
				Time[i] = (last-now)&0x00FFFFFF;  // 24-bit time difference
				Data[i] = GPIO_PORTF_DATA_R&0x13; // record PF0, PF1 and PF4
				
				last = now;
				i++;
			}
			//Delay(); 						// inaccurate Delay function
			SysTick_Wait10ms(5); 	// using hardware timer
		}		
	}
} 
