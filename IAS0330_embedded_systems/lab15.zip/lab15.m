%% Checkpoint 1.1:
% Using an LDR and connecting it as shown in the above schematic diagram, 
% does the voltage VOut get higher or lower for an increasing amount of light 
% on the LDR?
%
% ans: 
%   it gets higher with an increasing ammount of light in the LDR

%% Task 1.1
clc; clear all; close all

vi = 3.3; % fixed
r1_on = 200; % min LDR resist, full light
r1_off = 5000;  % max LDR resist, no light

syms r2
v = (vi * (r2./(r1_on+r2))) - (vi * (r2./(r1_off+r2)));
dv = diff(v);

interval = [0, 2e4];

hold on
subplot(2, 1, 1)
    fplot(v, interval)
    ylabel('v_{out} (V)')
    xlabel('r2 (ohm)')
subplot(2, 1, 2)
    fplot(dv, interval) 
    legend('dv/dr2')
    xlabel('r2 (ohm)')
grid


r2 =  vpasolve(dv==0,r2,interval) 
vo_max = subs(v)

%% Task 1.2

v_out_on = (vi * (r2./(r1_on+r2))) * 1000 % [mV]
v_out_off = (vi * (r2./(r1_off+r2))) * 1000 % [mV]


%% Checkpoint 1.2:
% Knowing that your ADC resolution is 12 bits, what is the maximum ADC value 
% you may have? Find an equation that converts ADC value to voltage.
% 
% ans: 
%   with 12 bits, the highest ADC value would be (2^12)-1 = 4095
% 
%   if our system voltage is 3.3V, then the voltage corresponding to an adc
%   reading would be:
%   V = adc_value * 3.3 / 4096

%% Task 1.3
% To sample PE2 at 40Hz, the following systick reload value is used:
period = 1/40;
clock_rate = 80e6;
n =(period * clock_rate)-1

% Part 1 Demo:
% https://youtu.be/7shqDZkYTDs


%% Checkpoint 2.1:
% What is the period time of a PWM signal if its frequency is 1kHz? 
% ans: 1/1000 = 1e-03 [sec.]


%% Checkpoint 2.2:
% The period time of a PWM signal is 25µs. Its on-time is 5µs. What is its off-time?
% ans: 20 micro seconds


%% Checkpoint 2.3:
% The period time of a PWM signal is 25µs. Its on-time is 5µs. What is its duty cycle?
% ans: (5 / 25)*100 = 20%

%% Task 2.1 
% systick reload value for 4khz:
period = 1/4000;
clock_rate = 80e6;
n =(period * clock_rate)-1

