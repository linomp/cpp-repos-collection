
#include "ADC.h"
#include "UART.h"
#include "Init.h"
#include "tm4c123gh6pm.h"

#define FALSE 0
#define TRUE  1

#define BUS_FREQ 80      		  // [MHz] bus clock

#define TOTAL_PERIOD 19999   // desired period: 0.00025ms (with 80MHz clock)

#define SUPPLY_VOLTAGE 3300   // [mV]
//find maximum value of ADC
#define ADC_MAX 4095         // 12-bit number
//find maximum volatage in mV
#define MAX_VOLT 2750  		  // [mV]  maximum expected voltage: 100%
//find minimum voltage in mV
#define MIN_VOLT 550    		  // [mV]  minimum expected voltage: 0%

// Port Inits in separate Init.h file for readability
void PortF_Init(void);
void PA2_Init(void);

void EnableInterrupts(void);      // Enable interrupts
void WaitForInterrupt(void);

unsigned long TimerCount;

unsigned long H,L; // PWM on/off counters 

unsigned long ADCdata = 0;        // 12-bit 0 to 4095 sample
unsigned long Flag = FALSE;       // The ADCdata is ready


//********Convert2Voltage****************
// Convert a 12-bit binary ADC sample into a 32-bit unsigned
// fixed-point voltage (resolution 1 mV).  
// Maximum and minimum values are calculated 
// and are dependant on resitor value.
// Overflow and dropout should be considered 
// Input: sample  12-bit ADC sample
// Output: 32-bit voltage (resolution 1 mV)
unsigned long Convert2Voltage(unsigned long sample)
{
	long voltage=0; 
	voltage = sample * SUPPLY_VOLTAGE / 4096; // [mV] 
	return voltage;
}

//********Convert2Percent****************
// Convert voltage reading into fixed-point precision
// luminosity percentage (resolution 0.1%). 
// Assume linear dependency.
// Input: voltage (mV)
// Output: fixed-point percent ((resolution 0.1%)
unsigned long Convert2Percent(unsigned long voltage)
{
	unsigned long percent = 0; 
	voltage = voltage < MIN_VOLT ? MIN_VOLT : (voltage > MAX_VOLT ? MAX_VOLT : voltage); // crop off exceeding values
	percent = (voltage - MIN_VOLT) * 1000 / (MAX_VOLT - MIN_VOLT);
	return percent;
}

// Initialize SysTick with interrupts 
void SysTick_Init(){
  NVIC_ST_CTRL_R = 0;        
	
	H = 10000; 
	L = TOTAL_PERIOD - H; // start at 50% duty cycle
		
  NVIC_ST_RELOAD_R = L; 
  
	NVIC_ST_CURRENT_R = 0;      
  NVIC_SYS_PRI3_R = (NVIC_SYS_PRI3_R&0x00FFFFFF)|0x40000000; // priority 2
                              // enable SysTick with core clock and interrupts
  NVIC_ST_CTRL_R = 0x07;
  EnableInterrupts();
}


void SysTick_Handler(void)
{ 	
	  if(GPIO_PORTA_DATA_R&0x4){   // toggle PA5 
			GPIO_PORTA_DATA_R &= ~0x4; // make PA5 low
			NVIC_ST_RELOAD_R = L-1;     // reload value for low phase  
		} else{
			GPIO_PORTA_DATA_R |= 0x4;  // make PA5 high 
			NVIC_ST_RELOAD_R = H-1;     // reload value for high phase
		} 
}

void adjustLED(unsigned long percent){ 	
	// the higher the percentage of luminosity, the dimmer the LED should be 
	// therefore, the higher the percentage, the lower the duty cycle 	
	L = TOTAL_PERIOD * percent/1000;
	H = TOTAL_PERIOD - L; 
}

void adcTask(void){
	//read from ADC on demand, at 40 Hz 
	unsigned long int voltage;
	
	GPIO_PORTF_DATA_R ^= 0x04; // toggle led on interrupt as well 
	ADCdata = ADC0_In(); 
	adjustLED( Convert2Percent(Convert2Voltage(ADCdata)) );
		
	voltage = Convert2Voltage(ADCdata);  
	UART_OutRaw( ADCdata );
	UART_OutChar(' '); 
	UART_OutVoltage( voltage );
	UART_OutChar(' '); 
	UART_OutPercent( Convert2Percent(voltage) );
	UART_OutChar('\n'); 
}

// Timer init and handler code adapted from Valvano material:
// http://users.ece.utexas.edu/~valvano/Volume1/E-Book/C15_CompleteEmbeddedSystem.htm#15_5
void Timer2_Init(unsigned long period){
  unsigned long volatile delay;
  SYSCTL_RCGCTIMER_R |= 0x04;   // 0) activate timer2
  delay = SYSCTL_RCGCTIMER_R;
  TimerCount = 0;
  TIMER2_CTL_R = 0x00000000;   // 1) disable timer2A
  TIMER2_CFG_R = 0x00000000;   // 2) 32-bit mode
  TIMER2_TAMR_R = 0x00000002;  // 3) periodic mode
  TIMER2_TAILR_R = period-1;   // 4) reload value
  TIMER2_TAPR_R = 0;           // 5) clock resolution
  TIMER2_ICR_R = 0x00000001;   // 6) clear timeout flag
  TIMER2_IMR_R = 0x00000001;   // 7) arm timeout
  NVIC_PRI5_R = (NVIC_PRI5_R&0x00FFFFFF)|0x80000000; // 8) priority 4
  NVIC_EN0_R = 1<<23;          // 9) enable IRQ 23 in
  TIMER2_CTL_R = 0x00000001;   // 10) enable timer2A
}


void Timer2A_Handler(void){ 
  TIMER2_ICR_R = 0x00000001;  // acknowledge
  TimerCount++;	
	
	adcTask();
}
 
// a simple main program allowing you to debug the ADC interface
int main(void){  
	PLL_Init();
	ADC0_Init(); 
	UART_Init();
	
	PortF_Init();  // built-in LED to blink on adc sample
	PA2_Init();    // LED to be driven by PWM
	 
	Timer2_Init(2000000); //  use another timer module for ADC sampling at 40Hz.  	
	SysTick_Init();	      // PWM generation is handled with systick
	
  EnableInterrupts();
  while(TRUE) {	
	  WaitForInterrupt();
	}
}

