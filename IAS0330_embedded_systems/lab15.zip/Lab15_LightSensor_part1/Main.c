
#include "ADC.h"
#include "UART.h"
#include "Init.h"
#include "tm4c123gh6pm.h"

#define FALSE 0
#define TRUE  1

#define BUS_FREQ 80      		  // [MHz] bus clock

#define SUPPLY_VOLTAGE 3300   // [mV]
//find maximum value of ADC
#define ADC_MAX 4095         // 12-bit number
//find maximum volatage in mV
#define MAX_VOLT 2750  		  // [mV]  maximum expected voltage: 100%
//find minimum voltage in mV
#define MIN_VOLT 550    		  // [mV]  minimum expected voltage: 0%


void EnableInterrupts(void);      // Enable interrupts
void WaitForInterrupt(void);

unsigned long ADCdata = 0;        // 12-bit 0 to 4095 sample
unsigned long Flag = FALSE;       // The ADCdata is ready

//********Convert2Voltage****************
// Convert a 12-bit binary ADC sample into a 32-bit unsigned
// fixed-point voltage (resolution 1 mV).  
// Maximum and minimum values are calculated 
// and are dependant on resitor value.
// Overflow and dropout should be considered 
// Input: sample  12-bit ADC sample
// Output: 32-bit voltage (resolution 1 mV)
unsigned long Convert2Voltage(unsigned long sample)
{
	long voltage=0; 
	voltage = sample * SUPPLY_VOLTAGE / 4096; // [mV] 
	return voltage;
}

//********Convert2Percent****************
// Convert voltage reading into fixed-point precision
// luminosity percentage (resolution 0.1%). 
// Assume linear dependency.
// Input: voltage (mV)
// Output: fixed-point percent ((resolution 0.1%)
unsigned long Convert2Percent(unsigned long voltage)
{
	long percent=0;
	//your code should be here
	return percent;
}

// Initialize SysTick with interrupts 
void SysTick_Init(){
  NVIC_ST_CTRL_R = 0;        
	 
  NVIC_ST_RELOAD_R = 1999999;// desired period: 0.025ms (with 80MHz clock)
  
	NVIC_ST_CURRENT_R = 0;      
  NVIC_SYS_PRI3_R = (NVIC_SYS_PRI3_R&0x00FFFFFF)|0x40000000; // priority 2
                              // enable SysTick with core clock and interrupts
  NVIC_ST_CTRL_R = 0x07;
  EnableInterrupts();
}

void PortF_Init(){
	unsigned long volatile delay;
	SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOF; // activate port F
  delay = SYSCTL_RCGC2_R;
	GPIO_PORTF_DIR_R |= 0x04;             // make PF2 out (built-in LED)
  GPIO_PORTF_AFSEL_R &= ~0x04;          
  GPIO_PORTF_DEN_R |= 0x04;              
  GPIO_PORTF_PCTL_R = (GPIO_PORTF_PCTL_R&0xFFFFF0FF)+0x00000000;
  GPIO_PORTF_AMSEL_R = 0;              
}
 
//read from ADC on demand, at 40 Hz 
void SysTick_Handler(void)
{ 	
		GPIO_PORTF_DATA_R ^= 0x04; // toggle led on interrupt as well
	
		ADCdata = ADC0_In(); 
		UART_OutVoltage( Convert2Voltage(ADCdata) );
	  UART_OutChar('\n'); 
}


 
int main(void){ 
	PLL_Init();
	ADC0_Init(); // initialize ADC0 for PE2, channel 1, sequencer 3
	UART_Init();
	PortF_Init();
	 
	SysTick_Init();		 
  while(TRUE){ 
		WaitForInterrupt();
	}
}
