
#include "ADC.h"
#include "UART.h"
#include "Init.h"
#include "tm4c123gh6pm.h"

#define FALSE 0
#define TRUE  1

#define BUS_FREQ 80      		  // [MHz] bus clock
 
#define TOTAL_PERIOD 19999   // desired period: 0.00025ms (with 80MHz clock)

void EnableInterrupts(void);      // Enable interrupts 

unsigned long H,L; // PWM on/off counters 

// Initialize SysTick with interrupts 
void SysTick_Init(){
  NVIC_ST_CTRL_R = 0;        
	
	H = 5000; 
	L = TOTAL_PERIOD - H; // start at 75% duty cycle  (leds in negative logic. low = led on) 
		
  NVIC_ST_RELOAD_R = L;
  
	NVIC_ST_CURRENT_R = 0;      
  NVIC_SYS_PRI3_R = (NVIC_SYS_PRI3_R&0x00FFFFFF)|0x40000000;   
  NVIC_ST_CTRL_R = 0x07;   
  EnableInterrupts();
}

void PortF_Init(){
	unsigned long volatile delay;
	SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOF; // activate port F
  delay = SYSCTL_RCGC2_R;
	GPIO_PORTF_DIR_R |= 0x04;             // make PF2 out (built-in LED)
  GPIO_PORTF_AFSEL_R &= ~0x04;          
  GPIO_PORTF_DEN_R |= 0x04;              
  GPIO_PORTF_PCTL_R = (GPIO_PORTF_PCTL_R&0xFFFFF0FF)+0x00000000;
  GPIO_PORTF_AMSEL_R = 0;      
	GPIO_PORTF_DATA_R &= ~0x4;   // make PF2 low 
}
 
void PA2_Init(){
	unsigned long volatile delay;
	SYSCTL_RCGC2_R |= 0x00000001; // activate clock for port A
  delay = SYSCTL_RCGC2_R; 
	GPIO_PORTA_AMSEL_R &= ~0x4;      // disable analog functionality on PA2
  GPIO_PORTA_PCTL_R &= ~0x00F00000; // configure PA2 as GPIO
  GPIO_PORTA_DIR_R |= 0x4;     // make PA2 out
  GPIO_PORTA_AFSEL_R &= ~0x4;  // disable alt funct on PA2
  GPIO_PORTA_DEN_R |= 0x4;     // enable digital I/O on PA2
  GPIO_PORTA_DATA_R &= ~0x4;   // make PA2 low  
}

// PWM at 4khz
// Based on TExasWare/C12_DCMotor
void SysTick_Handler(void)
{ 	 	 
		if(GPIO_PORTA_DATA_R&0x4){   // toggle PA5
			GPIO_PORTF_DATA_R &= ~0x4;
			GPIO_PORTA_DATA_R &= ~0x4; // make PA5 low
			NVIC_ST_RELOAD_R = L-1;     // reload value for low phase 
			 
		} else{
			GPIO_PORTA_DATA_R |= 0x4;  // make PA5 high
			GPIO_PORTF_DATA_R |= 0x4;
			NVIC_ST_RELOAD_R = H-1;     // reload value for high phase
		}   
}


void Delay(unsigned long time){
  unsigned long i;
  while(time > 0){
    i = 133333;  
    while(i > 0){
      i = i - 1;
    }
    time = time - 1;  
  }
}
 

int main(void){ 
	PLL_Init();
	UART_Init();	 
	
	PortF_Init();  // Also using built-in LED for easier visualization
	PA2_Init();   
	
	SysTick_Init();								
  EnableInterrupts();
  while(TRUE) {  
		volatile int i; 
		for (i = 0; i<200; i++){
			if(i<100){
				H = TOTAL_PERIOD * i/100;
			}else{
				H = TOTAL_PERIOD * (199-i)/100;
			}
			L = TOTAL_PERIOD - H; 
			Delay(1);
		}
	}
}
